// Student Management System - XML, JSON and JavaScript
// All records are stored in the browser for this session only.

document.addEventListener("DOMContentLoaded", () => {
  let students = [];

  const tableBody = document.getElementById("studentTableBody");
  const searchInput = document.getElementById("searchInput");
  const studentCount = document.getElementById("studentCount");
  const visibleCount = document.getElementById("visibleCount");
  const sourceLabel = document.getElementById("sourceLabel");
  const recordMessage = document.getElementById("recordMessage");
  const formMessage = document.getElementById("formMessage");
  const xmlButton = document.getElementById("loadXmlBtn");
  const jsonButton = document.getElementById("loadJsonBtn");
  const studentForm = document.getElementById("studentForm");

  // Show student records in the table.
  function displayStudents(records = students) {
    tableBody.innerHTML = "";

    if (records.length === 0) {
      const row = document.createElement("tr");
      row.className = "empty-row";
      const cell = document.createElement("td");
      cell.colSpan = 5;
      cell.textContent = "No matching student records found.";
      row.appendChild(cell);
      tableBody.appendChild(row);
    } else {
      records.forEach((student) => {
        const row = document.createElement("tr");
        [student.id, student.name, student.age, student.department, student.email]
          .forEach((value, index) => {
            const cell = document.createElement("td");
            cell.textContent = String(value ?? "");
            if (index === 0) cell.className = "id-cell";
            row.appendChild(cell);
          });
        tableBody.appendChild(row);
      });
    }

    studentCount.textContent = String(students.length);
    visibleCount.textContent = `${records.length} record${records.length === 1 ? "" : "s"}`;
  }

  function showLoadError(error, filename) {
    console.error(`Error loading ${filename}:`, error);
    recordMessage.textContent = `Could not load ${filename}. Make sure all project files are in the same folder and open index.html with VS Code Live Server. Details: ${error.message}`;
  }

  // TASK 3: Read XML using Fetch and parse it with DOMParser.
  xmlButton.addEventListener("click", async () => {
    recordMessage.textContent = "Loading XML student records...";
    xmlButton.disabled = true;
    try {
      const response = await fetch("./students.xml", { cache: "no-store" });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);

      const xmlText = await response.text();
      const xmlDocument = new DOMParser().parseFromString(xmlText, "application/xml");
      if (xmlDocument.querySelector("parsererror")) {
        throw new Error("Invalid XML format. Please check students.xml.");
      }

      const xmlStudents = Array.from(xmlDocument.getElementsByTagName("student"));
      if (xmlStudents.length === 0) throw new Error("No student records were found in students.xml.");

      students = xmlStudents.map((item) => {
        const getValue = (tag) => {
          const element = item.getElementsByTagName(tag)[0];
          if (!element) throw new Error(`Missing <${tag}> in an XML student record.`);
          return element.textContent.trim();
        };
        return {
          id: getValue("id"),
          name: getValue("name"),
          age: getValue("age"),
          department: getValue("department"),
          email: getValue("email")
        };
      });

      sourceLabel.textContent = "XML";
      recordMessage.textContent = `Successfully loaded ${students.length} students from students.xml.`;
      searchInput.value = "";
      displayStudents();
    } catch (error) {
      showLoadError(error, "students.xml");
    } finally {
      xmlButton.disabled = false;
    }
  });

  // TASK 4: Read JSON using Fetch and response.json().
  jsonButton.addEventListener("click", async () => {
    recordMessage.textContent = "Loading JSON student records...";
    jsonButton.disabled = true;
    try {
      const response = await fetch("./students.json", { cache: "no-store" });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);

      const data = await response.json();
      if (!Array.isArray(data)) throw new Error("JSON must contain an array of students.");
      if (data.length === 0) throw new Error("No student records were found in students.json.");

      students = data.map((student) => {
        const required = ["id", "name", "age", "department", "email"];
        required.forEach((key) => {
          if (student[key] === undefined || student[key] === null) {
            throw new Error(`A JSON student record is missing: ${key}`);
          }
        });
        return {
          id: student.id,
          name: String(student.name),
          age: student.age,
          department: String(student.department),
          email: String(student.email)
        };
      });

      sourceLabel.textContent = "JSON";
      recordMessage.textContent = `Successfully loaded ${students.length} students from students.json.`;
      searchInput.value = "";
      displayStudents();
    } catch (error) {
      showLoadError(error, "students.json");
    } finally {
      jsonButton.disabled = false;
    }
  });

  // TASK 5: Search students by name, ignoring uppercase/lowercase.
  searchInput.addEventListener("input", () => {
    const term = searchInput.value.trim().toLowerCase();
    const matches = students.filter((student) =>
      student.name.toLowerCase().includes(term)
    );
    displayStudents(matches);
  });

  // TASK 6: Add a student to the current webpage session.
  studentForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const newStudent = {
      id: `STU${String(Date.now()).slice(-6)}`,
      name: document.getElementById("studentName").value.trim(),
      age: document.getElementById("studentAge").value,
      department: document.getElementById("studentDepartment").value.trim(),
      email: document.getElementById("studentEmail").value.trim()
    };

    students.push(newStudent);
    sourceLabel.textContent = "Updated list";
    recordMessage.textContent = "New student added to the webpage. This change is temporary.";
    searchInput.value = "";
    displayStudents();
    studentForm.reset();
    formMessage.textContent = "Student added successfully!";
  });

  // Initial empty state.
  displayStudents();
});
